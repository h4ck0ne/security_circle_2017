<?php

return array(

    'DR_UPDATE'		=> '2017.6.14',
    'DR_VERSION'	=> '5.0.8',
);
