<?php

/**
 * FineCMS
 */

/**
 * 站点域名文件
 */

return array(

	'www.gyb.com'                   => 1,

);