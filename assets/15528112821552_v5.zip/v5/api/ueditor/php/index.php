<?php

define('IS_MEMBER', TRUE);
define('DR_UEDITOR', 'ueditor'); // 自定义编辑器目录,不能以/结尾
require dirname(dirname(dirname(dirname(__FILE__)))).DIRECTORY_SEPARATOR.'index.php';
